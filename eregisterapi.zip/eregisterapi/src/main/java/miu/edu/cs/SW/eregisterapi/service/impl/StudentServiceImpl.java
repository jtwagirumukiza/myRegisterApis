package miu.edu.cs.SW.eregisterapi.service.impl;

import java.util.List;


import miu.edu.cs.SW.eregisterapi.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import miu.edu.cs.SW.eregisterapi.model.Student;

import miu.edu.cs.SW.eregisterapi.service.StudentService;
@Service
public class StudentServiceImpl implements StudentService{
	StudentRepository studentRepository;
@Autowired
	public StudentServiceImpl(StudentRepository studentRepository) {
		this.studentRepository = studentRepository;
	}

	
@Override 
public List<Student> getAllStudents() {
	return (List<Student>) studentRepository.findAll();
}


public Student getStudentById(Long studentId) {
	return studentRepository.findById(studentId).orElse(null);
}

@Override 
public void deleteStudentById(Long studentId) {
	studentRepository.deleteById(studentId);
}


public Student updateStudent(Student editedStudent, Long studentId) {
	return studentRepository.findById(studentId)
			.map(student -> {
				student.setStudentNumber(editedStudent.getStudentNumber());
				student.setFirstName(editedStudent.getFirstName());
				student.setMiddleName(editedStudent.getMiddleName());
				student.setLastName(editedStudent.getLastName());
				student.setCgpa(editedStudent.getCgpa());
				student.setEnrollmentDate(editedStudent.getEnrollmentDate());
				student.setIsInternational(editedStudent.getIsInternational());

				return studentRepository.save(student);
			}).orElseGet(() -> {
				return studentRepository.save(editedStudent);
			});
}


@Override
public Student registerNewStudent(Student student) {
	
	return studentRepository.save(student);
}



	


}
	
	


