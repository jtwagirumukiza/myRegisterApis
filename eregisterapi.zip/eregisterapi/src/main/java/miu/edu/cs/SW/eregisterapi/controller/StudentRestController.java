package miu.edu.cs.SW.eregisterapi.controller;

import miu.edu.cs.SW.eregisterapi.model.Student;
import miu.edu.cs.SW.eregisterapi.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping(value="/eregister/api/student", produces = MediaType.APPLICATION_JSON_VALUE)
public class StudentRestController {
    StudentService studentService;
@Autowired
    public StudentRestController(StudentService studentService) {
        this.studentService = studentService;
    }


   @PostMapping(value = "/register")
   public Student registerNewStudent(@Valid @RequestBody Student student) {
       return studentService.registerNewStudent(student);
    }

    @GetMapping(value = "/list")
    public List<Student> list() {
        return studentService.getAllStudents();
    }

    @GetMapping(value = "/get/{studentId}")
    public Student getStudentById(@PathVariable Long studentId) {
        return studentService.getStudentById(studentId);
    }
    @DeleteMapping(value = "/delete/{studentId}")
    public void deleteStudent(@PathVariable Long studentId) {
        studentService.deleteStudentById(studentId);
    }

   @PutMapping(value = "/update/{studentId}")
    public Student updateStudent(@Valid @RequestBody Student editedStudent, @PathVariable Long studentId) {
        return studentService.updateStudent(editedStudent, studentId);
    }
}
