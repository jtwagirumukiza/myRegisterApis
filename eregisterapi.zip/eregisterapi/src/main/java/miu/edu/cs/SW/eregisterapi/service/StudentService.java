package miu.edu.cs.SW.eregisterapi.service;

import java.util.List;

import miu.edu.cs.SW.eregisterapi.model.Student;

public interface StudentService {
public Student registerNewStudent (Student student);
public List<Student> getAllStudents();
public Student getStudentById(Long studentId);
public void deleteStudentById(Long studentId);
Student updateStudent(Student editedStudent, Long studentId);

}
