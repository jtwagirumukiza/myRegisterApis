package miu.edu.cs.SW.eregisterapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EregisterapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(EregisterapiApplication.class, args);
	}

}
