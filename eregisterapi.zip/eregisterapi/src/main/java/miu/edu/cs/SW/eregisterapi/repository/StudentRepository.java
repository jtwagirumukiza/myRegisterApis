package miu.edu.cs.SW.eregisterapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import miu.edu.cs.SW.eregisterapi.model.Student;

public interface StudentRepository extends CrudRepository<Student, Long> {

}
