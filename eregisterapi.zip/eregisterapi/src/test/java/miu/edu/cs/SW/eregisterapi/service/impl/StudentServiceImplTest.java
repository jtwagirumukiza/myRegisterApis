package miu.edu.cs.SW.eregisterapi.service.impl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class StudentServiceImplTest {

    @BeforeEach
    void setUp() {
    }

    @Test
    void getAllStudents() {
        assertEquals(1,1);
    }
}