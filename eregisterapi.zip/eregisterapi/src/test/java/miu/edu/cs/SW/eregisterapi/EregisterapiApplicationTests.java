package miu.edu.cs.SW.eregisterapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EregisterapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
